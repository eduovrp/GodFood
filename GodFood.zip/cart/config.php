<?php
$currency = 'R$'; //Currency sumbol or code

//paypal settings
$PayPalMode 			= 'sandbox'; // sandbox or live
$PayPalApiUsername 		= 'financeiro_api1.godfood.com.br'; //PayPal API Username
$PayPalApiPassword 		= 'UQMD7M78VUKBU9MR'; //Paypal API password
$PayPalApiSignature 	= 'AFcWxV21C7fd0v3bYYYRCpSSRl31Acrh8QOqYaGJ99nUQHUpkJqcn6dp'; //Paypal API Signature
$PayPalCurrencyCode 	= 'BRL'; //Paypal Currency Code
$PayPalReturnURL 		= 'http://godfood.com.br/cart/process.php'; //Point to process.php page
$PayPalCancelURL 		= 'http://godfood.com.br/cart/cancel_url.php'; //Cancel URL if user clicks cancel

?>
