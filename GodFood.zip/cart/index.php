<?php
header('Location: view_cart.php');