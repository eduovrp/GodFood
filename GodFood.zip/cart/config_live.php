<?php
$currency = 'R$'; //Currency sumbol or code

//paypal settings
$PayPalMode 			= 'live'; // sandbox or live
$PayPalApiUsername 		= 'admin_api1.godfood.com.br'; //PayPal API Username
$PayPalApiPassword 		= '8VP47G654WN4KP4M'; //Paypal API password
$PayPalApiSignature 	= 'AQg0CP5y8tCvccxAVKAuPoz.Nl6VA.MUbC-Lz0ikitWB.ccB9VXg1v.2'; //Paypal API Signature
$PayPalCurrencyCode 	= 'BRL'; //Paypal Currency Code
$PayPalReturnURL 		= 'http://localhost/GodFood-v2.0/cart/process.php'; //Point to process.php page
$PayPalCancelURL 		= 'http://localhost/GodFood-v2.0/cart/cancel_url.php'; //Cancel URL if user clicks cancel

?>
