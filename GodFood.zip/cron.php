<?php
require 'functions/restaurantes.php';
echo 'Fecha Restaurantes';
fechaRestaurantesMadrugaBoladona();

 ?>